var class_amplify_shader_editor_1_1_commentary_node =
[
    [ "Draw", "class_amplify_shader_editor_1_1_commentary_node.html#ad4fe5f265d464b105cb93d5404aa4703", null ],
    [ "OnNodeLayout", "class_amplify_shader_editor_1_1_commentary_node.html#a04a4b379d9c1eca41c8dca61a1b02883", null ],
    [ "OnNodeRepaint", "class_amplify_shader_editor_1_1_commentary_node.html#ae7ef44042ab4969e051f465dfb4e3ad3", null ]
];