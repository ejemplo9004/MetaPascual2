var class_amplify_shader_editor_1_1_get_local_var_node =
[
    [ "Draw", "class_amplify_shader_editor_1_1_get_local_var_node.html#a30a9476b12e8b13360783fee64540085", null ],
    [ "OnNodeLogicUpdate", "class_amplify_shader_editor_1_1_get_local_var_node.html#ae664befa49f06524504588eca21af81f", null ],
    [ "OnNodeRepaint", "class_amplify_shader_editor_1_1_get_local_var_node.html#aa8538e87f5cd559a723ccba80497886a", null ]
];