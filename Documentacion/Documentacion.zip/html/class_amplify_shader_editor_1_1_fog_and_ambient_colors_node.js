var class_amplify_shader_editor_1_1_fog_and_ambient_colors_node =
[
    [ "Draw", "class_amplify_shader_editor_1_1_fog_and_ambient_colors_node.html#aa6ec0468af8840d93b13fde155875d48", null ]
];