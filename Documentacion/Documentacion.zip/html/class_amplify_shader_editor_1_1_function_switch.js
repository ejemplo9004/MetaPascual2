var class_amplify_shader_editor_1_1_function_switch =
[
    [ "Draw", "class_amplify_shader_editor_1_1_function_switch.html#ac58e0d457debbe05776471819fdbce9d", null ],
    [ "DrawGUIControls", "class_amplify_shader_editor_1_1_function_switch.html#a465b19842ab2fb1f631681cfd69ddfce", null ],
    [ "OnNodeLayout", "class_amplify_shader_editor_1_1_function_switch.html#a3f8cb79653da10a54a3a9812552193a8", null ],
    [ "OnNodeLogicUpdate", "class_amplify_shader_editor_1_1_function_switch.html#abc132b18703ae5de39cac3c8668d7515", null ],
    [ "OnNodeRepaint", "class_amplify_shader_editor_1_1_function_switch.html#ac6b726ee10331fcf6f8fad78eacb0cb2", null ]
];