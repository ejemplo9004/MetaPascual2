var class_amplify_shader_editor_1_1_color_node =
[
    [ "Draw", "class_amplify_shader_editor_1_1_color_node.html#a7dde1903d46e1cd170671bf7745750da", null ],
    [ "DrawGUIControls", "class_amplify_shader_editor_1_1_color_node.html#afd0bb7c946ef986aac848a53d4b1d6a5", null ],
    [ "OnNodeLayout", "class_amplify_shader_editor_1_1_color_node.html#a0b13d0f036a45485ab78e0ca956e5861", null ]
];