var class_amplify_shader_editor_1_1_indirect_diffuse_lighting =
[
    [ "Draw", "class_amplify_shader_editor_1_1_indirect_diffuse_lighting.html#a5bc0c00d36115e9fc9c400696dbadefd", null ]
];