var class_amplify_shader_editor_1_1_function_node =
[
    [ "Draw", "class_amplify_shader_editor_1_1_function_node.html#a7f8f68c8e7c8db9bc639c1f57739b558", null ],
    [ "OnNodeLogicUpdate", "class_amplify_shader_editor_1_1_function_node.html#a723b933cb7f1c313bc1faa394573229f", null ]
];