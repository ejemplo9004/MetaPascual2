var class_amplify_shader_editor_1_1_indirect_specular_light =
[
    [ "Draw", "class_amplify_shader_editor_1_1_indirect_specular_light.html#a1045f5100ecff614f801e6f44b7f6d96", null ]
];