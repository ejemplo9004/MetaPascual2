var class_amplify_shader_editor_1_1_light_attenuation =
[
    [ "Draw", "class_amplify_shader_editor_1_1_light_attenuation.html#ab6f7808373c73b5a4018d2001fa600f1", null ]
];