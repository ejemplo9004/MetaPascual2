var class_amplify_shader_editor_1_1_dynamic_type_node =
[
    [ "OnNodeLogicUpdate", "class_amplify_shader_editor_1_1_dynamic_type_node.html#a7f30b8257909644f24f149304d052610", null ]
];