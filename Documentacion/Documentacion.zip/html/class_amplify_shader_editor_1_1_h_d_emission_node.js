var class_amplify_shader_editor_1_1_h_d_emission_node =
[
    [ "OnNodeLogicUpdate", "class_amplify_shader_editor_1_1_h_d_emission_node.html#ae276eaae6ab662bacce8914530f29c10", null ]
];